Added IRV_LOCREG table domain.

Associated IRV_LOCREG with LOCATIONSPEC.ALNVALUE

Added IRVREGSPEC relationship to locations.

Added Field to Locations,SR and WO applications advanced search. 

Description of IRV_NSCREG,IRV_BBCREG,IRV_IRVREG changed to add region details

Change domain values on IRV_NSCREG

Changed NSCREG Asset attribute to IRV_NSCREG

Domains:

'IRV_LOCREG','IRV_NSCREG','IRV_BBCREG','IRV_IRVREG'