Report was bringing back duplicates due to the Job Plan being revised, code now fixed.

Also added the task step long descriptions instead of picking up the work order long description.