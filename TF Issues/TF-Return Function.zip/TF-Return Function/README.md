Process now does the following:

Completes current assignment.

Adds new assignment.

Changes Record to WAPPR.

Assigns to NSCSD Group.

Adds Work log to Work Order.

Displays Message to user to reassign work order. 