Deployment Order:

Deploy Actions Package
Deploy Workflow Package
Enable SUBWOPO Process
Enable ESTREQ Process
Resync MAINWOWF