Add Classifications for locations with Region Specifications

Load Data from sheet provided. 